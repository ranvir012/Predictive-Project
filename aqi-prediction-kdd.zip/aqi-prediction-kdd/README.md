# Next-Day AQI Prediction for Indian Cities using Machine Learning (KDD approach)

Predicts tomorrow's Air Quality Index (AQI) for Indian cities from today's and recent pollutant readings:
- **Regression**: next-day AQI value
- **Classification**: next-day AQI category (Good, Satisfactory, Moderate, Poor, Very Poor, Severe)

Author: **YOUR NAME**

## KDD pipeline
Data Selection -> EDA -> Preprocessing -> Feature Engineering -> Chronological Split -> Baseline Models ->
Advanced Models (Random Forest, XGBoost) -> AQI Classification -> Evaluation (MAE, RMSE, R2, F1) -> Interpretation (SHAP)

## Repository structure
```
aqi-prediction-kdd/
├── notebooks/AQI_Prediction_KDD.ipynb   # step-by-step notebook (Colab friendly)
├── src/aqi_kdd_pipeline.py              # same pipeline as one script; also builds the PPT
├── data/                                # city_day.csv is downloaded here (see data/README.md)
├── sample_data/                         # SYNTHETIC csv, only for testing the code
├── outputs/                             # figures, results.json and the generated PPT
├── docs/                                # preview presentation (sample numbers)
└── requirements.txt
```

## Quick start
**Google Colab:** upload `notebooks/AQI_Prediction_KDD.ipynb`, set `AUTHOR_NAME`, then Runtime -> Run all.

**Local:**
```bash
pip install -r requirements.txt
# edit AUTHOR_NAME in src/aqi_kdd_pipeline.py
python src/aqi_kdd_pipeline.py        # run from the repo root
```
Results appear in `outputs/` (figures, `results.json`, `AQI_Prediction_KDD.pptx`).

## Method summary
| Stage | What is done |
|---|---|
| Data selection | `city_day.csv`: daily readings for many Indian cities, 2015-2020 |
| EDA | missing values, AQI distribution, city comparison, seasonality, correlations |
| Preprocessing | full daily calendar per city, causal forward-fill (max 3 days), train-median imputation, outlier capping, drop columns >50% missing |
| Features | lags (1, 2, 3, 7 days) of AQI/PM2.5/PM10, rolling mean/std, day-to-day change, calendar and winter flag, city one-hot |
| Split | chronological 70% train / 15% validation / 15% test (no shuffling) |
| Baselines | persistence ("tomorrow = today"), Linear, Ridge |
| Advanced | Random Forest, XGBoost (early stopping on validation) |
| Classification | persistence, Logistic Regression, Random Forest, XGBoost, XGBoost-regressor binned |
| Metrics | MAE, RMSE, R2 (regression); accuracy, macro-F1, weighted-F1 (classification) |
| Interpretation | SHAP on XGBoost |

## Results
Run the project to fill this in from `outputs/results.json`.

| Model | MAE | RMSE | R2 |
|---|---|---|---|
| Persistence | | | |
| Linear / Ridge | | | |
| Random Forest | | | |
| XGBoost | | | |

## Limitations
No meteorological data, many missing readings, uneven station coverage, and the test period probably includes
the 2020 COVID-19 lockdown (distribution shift). Rare "Severe" days are hard to classify.

## Data source
[Kaggle: Air Quality Data in India](https://www.kaggle.com/datasets/rohanrao/air-quality-data-in-india) - please check the dataset's license/terms.
